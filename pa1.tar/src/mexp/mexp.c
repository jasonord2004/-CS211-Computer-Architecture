#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to multiply two matrices 

void multiply(int** a, int** b, int** c, int size) {

    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            //printf("i: %d, j: %d, %d\n", i, j, A[0][0]); 
            c[i][j] = 0;
            for (int k = 0; k < size; k++) {
            //printf("A: %d, B: %d, C: %d\n", A[0][0], B[k][j], C[i][j]);
            c[i][j] = c[i][j] + a[i][k] * b[k][j];
            //printf("i: %d, j: %d, k: %d, A[i][0]: %d, B[k][j]: %d, C[i][j]: %d\n", i, j, k, a[i][k], b[k][j], c[i][j]);
            }
            //printf("NEXT");
        }
    }
}

int main(int argc, char* argv[]) {

    // Open file 
    FILE* fptr = fopen(argv[1], "r");

    // Read size
    int size;
    fscanf(fptr, "%d", &size);
    //printf("SIZE: %d\n", size);

    // Allocate matrices  
    int** A = (int**)malloc(size * sizeof(int*));
    for (int i = 0; i < size; i++) {
        A[i] = (int*)malloc(size * sizeof(int)); 
    }

    int** B = (int**)malloc(size * sizeof(int*));
    for (int i = 0; i < size; i++) {
        B[i] = (int*)malloc(size * sizeof(int));
    }

    int** C = (int**)malloc(size * sizeof(int*));
    for (int i = 0; i < size; i++) {
        C[i] = (int*)malloc(size * sizeof(int));
    }

    // Read matrix A
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
        fscanf(fptr, "%d", &A[i][j]);
        //printf("i: %d, j: %d, %d\n", i, j, A[i][j]);
        }
    }
    // Matrices C = A
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            B[i][j] = A[i][j];
            //printf("i: %d, j: %d, %d\n", i, j, A[i][j]);
        }
    }


    // Read power
    int pow;
    fscanf(fptr, "%d", &pow);
    //printf("POWER: %d\n", pow);

    // Compute A^pow
   // memcpy(B, A, size * size * sizeof(int));
    // int which = 0;
    for (int i = 1; i < pow; i++) {

        // for (int i = 0; i < size; i++) {
        //     for (int j = 0; j < size; j++) {
        //         if(j == size - 1){
        //             printf("%d", C[i][j]);
        //         } else {
        //             printf("%d ", C[i][j]);    
        //         }
        //     }
        //     printf("\n");
        //  }

            multiply(A, B, C, size);
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                B[i][j] = C[i][j];
                //printf("i: %d, j: %d, %d\n", i, j, A[i][j]);
            }
        }
            

        // which = 0;

        // printf("\n which: %d\n", which);

        // for (int i = 0; i < size; i++) {
        //     for (int j = 0; j < size; j++) {
        //         if(j == size - 1){
        //             printf("%d", C[i][j]);
        //         } else {
        //             printf("%d ", C[i][j]);    
        //         }
        //     }
        //     printf("\n");
        //  }
    }

    // Print result
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            if(j == size - 1){
                    printf("%d", C[i][j]);
            } else {
                    printf("%d ", C[i][j]);
            }

        }
        printf("\n");
    }

    // Free memory

    for (int i = 0; i < size; i++) {
        free(A[i]);
        free(B[i]);
        free(C[i]);
    }

    free(A);
    free(B);
    free(C);
    

    fclose(fptr);

    return 0;
}