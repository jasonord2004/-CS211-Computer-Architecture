#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* left;
    struct Node* right;
};

struct Node* createNode(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

struct Node* findMin(struct Node* root) {
    while (root->left != NULL) {
        root = root->left;
    }
    return root;
}

struct Node* deleteNode(struct Node* root, int data) {
    if (root == NULL) {
        return root;
    }

    if (data < root->data) {
        root->left = deleteNode(root->left, data);
    } else if (data > root->data) {
        root->right = deleteNode(root->right, data);
    } else {
        if (root->left == NULL) {
            struct Node* temp = root->right;
            free(root);
            return temp;
        } else if (root->right == NULL) {
            struct Node* temp = root->left;
            free(root);
            return temp;
        }

        struct Node* temp = findMin(root->right);
        root->data = temp->data;
        root->right = deleteNode(root->right, temp->data);
    }

    return root;
}

int insert(struct Node** root, int data) {
    if (*root == NULL) {
        *root = createNode(data);
        return 1; // inserted
    }
    if (data < (*root)->data) {
        return insert(&(*root)->left, data);
    } else if (data > (*root)->data) {
        return insert(&(*root)->right, data);
    }
    return 0; // not inserted
}

int search(struct Node* root, int data) {
    if (root == NULL) {
        return 0; // absent
    }
    if (data == root->data) {
        return 1; // present
    }
    if (data < root->data) {
        return search(root->left, data);
    }
    return search(root->right, data);
}

void printTree(struct Node* root) {
    if (root == NULL) {
        return;
    }
    printf("(");
    printTree(root->left);
    printf("%d", root->data);
    printTree(root->right);
    printf(")");
}

void deleteTree(struct Node* root) {
    if (root != NULL) {
        deleteTree(root->left);
        deleteTree(root->right);
        free(root);
    }
}

int main() {
    struct Node* root = NULL;
    char command;
    int data, result;

    while (1) {
        if (scanf(" %c", &command) == EOF) {
            break; // End of input
        }

        switch (command) {
            case 'i': // Insert
                if (scanf("%d", &data) == 1) {
                    result = insert(&root, data);
                    printf(result ? "inserted\n" : "not inserted\n");
                }
                break;
            case 's': // Search
                if (scanf("%d", &data) == 1) {
                    result = search(root, data);
                    printf(result ? "present\n" : "absent\n");
                }
                break;
            case 'p': // Print
                printTree(root);
                printf("\n");
                break;
            case 'd': // Delete
                if (scanf("%d", &data) == 1) {
                    result = search(root, data);
                    if (result) {
                        root = deleteNode(root, data);
                        printf("deleted\n");
                    } else {
                        printf("absent\n");
                    }
                }
                break;
            default:
                break;
        }
    }

    deleteTree(root); // Deallocate memory before exiting

    return 0;
}
