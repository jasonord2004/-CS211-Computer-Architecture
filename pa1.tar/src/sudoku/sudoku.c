#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

int main(int argc, char* argv[]){
    FILE* file = fopen(argv[1], "r");
    if (file == NULL){
        printf("error");
        return 0;
    }
    
    int y, f, g, h, i, j, k, l, m;
    //value of mode determines if checking for correctness(0) or solvability(1) 
    int mode = 0;
    int count = 0;

    int arr[91];
    int check[9] = {1, 2, 3, 4, 5, 6, 7, 8, 9};

    //POPULATES Arr ARRAY
    for(i = 0; i < 90; i++){
        //printf("CHAR: %d\n", fgetc(file) - '0');
        y = fgetc(file) - '0';
        if((y) == -38){
            count++;
        } else {
            arr[i-count] = y;
        }
        if(arr[i-count] == 47){
            mode = 1;
        }
        //printf("count: %d, y: %d, i: %d, arr: %d\n", count, y, i, arr[i-count]);
    }
    
    if(mode == 0){
        int row[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
        int column[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
        for(j = 0; j < 81; j++){
            for(k = 0; k < 9; k++){
                if(j%9 == 0 && j != 0){
                    //resets row after every row
                    for(h = 0; h < 9; h++){
                        row[h] = 0;
                        //printf("RESET\n");
                    }
                }  
            //checks rows
            //printf("k: %d\n", k);
                if(arr[j] == check[k] && row[k] == 1){
                    printf("incorrect\n");
                    return 0;
                } 
                if (arr[j] == check[k]){
                    //printf("arr[j]: %d, j: %d, k: %d, row[k]: %d, changing\n", arr[j], j, k, row[k]);
                    row[k] = 1;
                }
            //checks columns ERROR HEREE
                if(j < 9){
                    for(f = 0; f < 9; f++){
                        // for(int u = 0; u < 9; u++){
                        //     printf("COLUMN: %d\n", column[u]);
                        // }
                        //printf("j: %d, k: %d, f: %d\n", j, k, f);

                        if(arr[j+(9*(k))] == check[f] && column[f] == 1){
                            //printf("arr[j]: %d, arr[j+(9*(k))]: %d, j: %d, k: %d, j+(9*(k)): %d, f: %d, column[f]: %d, incorrect\n", arr[j], arr[j+(9*(k))], j, k, j+(9*(k)), f, column[f]);
                            printf("incorrect\n");
                            return 0;
                        } 
                        if (arr[j+(9*(k))] == check[f]){
                            //printf("arr[j]: %d, arr[j+(9*(k))]: %d, j: %d, k: %d, j+(9*(k)): %d, f: %d, column[f]: %d, changing\n", arr[j], arr[j+(9*(k))], j, k, j+(9*(k)), f, column[f]);
                            column[f] = 1;
                        }
                    }
                }
            }
            //resets column array after every column
            for(h = 0; h < 9; h++){
                column[h] = 0;
                //printf("RESET\n");
            }
        }
        //checks 3x3
        int test3[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
        //counter is for which row the code is on
        int counter = 0;
        for(g = 0; g < 63; g++){ //traverses every digit in a row
            for(l = 0; l < 3; l++){//compares downwards by 2
                for(m = 0; m < 9; m++){ //compares uniqueness of digit
                    if((counter)%3 == 0){
                        //printf("counter: %d, g: %d, l: %d, g+9l: %d, Check: %d vs %d\n", counter, g, l, g+(9*l), check[m], arr[g+(9*l)]);
                        if(arr[g+(9*l)] == check[m] && test3[m] == 1){
                            printf("incorrect\n");
                            return 0;
                        } else if (arr[g+(9*l)] == check[m]){
                            test3[m] = 1;
                        }
                    }
                }
                if((g+1)%3 == 0){
                    for(int fill = 0; fill < 9; fill++){
                        test3[fill] = 0;
                    }
                }
            }
            if((g+1)%9 == 0){
                counter++;
            }
        }
        
    printf("correct\n");

    } else if (mode == 1){
        int row[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
        int column[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
        for(j = 0; j < 81; j++){
            for(k = 0; k < 9; k++){
                if(j%9 == 0 && j != 0){
                    //resets row after every row
                    for(h = 0; h < 9; h++){
                        row[h] = 0;
                        //printf("RESET\n");
                    }
                }  
            //checks rows
            //printf("k: %d\n", k);
                if(arr[j] == check[k] && row[k] == 1){
                    printf("unsolvable\n");
                    return 0;
                } 
                if (arr[j] == check[k]){
                    //printf("arr[j]: %d, j: %d, k: %d, row[k]: %d, changing\n", arr[j], j, k, row[k]);
                    row[k] = 1;
                }
            //checks columns ERROR HEREE
                if(j < 9){
                    for(f = 0; f < 9; f++){
                        // for(int u = 0; u < 9; u++){
                        //     printf("COLUMN: %d\n", column[u]);
                        // }
                        //printf("j: %d, k: %d, f: %d\n", j, k, f);

                        if(arr[j+(9*(k))] == check[f] && column[f] == 1){
                            //printf("arr[j]: %d, arr[j+(9*(k))]: %d, j: %d, k: %d, j+(9*(k)): %d, f: %d, column[f]: %d, incorrect\n", arr[j], arr[j+(9*(k))], j, k, j+(9*(k)), f, column[f]);
                            printf("unsolvable\n");
                            return 0;
                        } 
                        if (arr[j+(9*(k))] == check[f]){
                            //printf("arr[j]: %d, arr[j+(9*(k))]: %d, j: %d, k: %d, j+(9*(k)): %d, f: %d, column[f]: %d, changing\n", arr[j], arr[j+(9*(k))], j, k, j+(9*(k)), f, column[f]);
                            column[f] = 1;
                        }
                    }
                }
            }
            //resets column array after every column
            for(h = 0; h < 9; h++){
                column[h] = 0;
                //printf("RESET\n");
            }
        }
        //checks 3x3
        int test3[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
        //counter is for which row the code is on
        int counter = 0;
        for(g = 0; g < 63; g++){ //traverses every digit in a row
            for(l = 0; l < 3; l++){//compares downwards by 2
                for(m = 0; m < 9; m++){ //compares uniqueness of digit
                    if((counter)%3 == 0){
                        //printf("counter: %d, g: %d, l: %d, g+9l: %d, Check: %d vs %d\n", counter, g, l, g+(9*l), check[m], arr[g+(9*l)]);
                        if(arr[g+(9*l)] == check[m] && test3[m] == 1){
                            printf("unsolvable\n");
                            return 0;
                        } else if (arr[g+(9*l)] == check[m]){
                            test3[m] = 1;
                        }
                    }
                }
                if((g+1)%3 == 0){
                    for(int fill = 0; fill < 9; fill++){
                        test3[fill] = 0;
                    }
                }
            }
            if((g+1)%9 == 0){
                counter++;
            }
    }
    int missing[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
    for(int c = 0; c < 81; c++){
        for(int d = 0; d < 9; d++){
            if(arr[c] == check[d]){
                missing[d]++;
            }
        }
    }
    int counter2 = 0;
    for(int e = 0; e < 9; e++){
        if(missing[e] == 9){
            counter2 = counter2+1;
        }
        //printf("INDEX: %d, QUANTITY: %d\n", e, missing[e]);
    }
    if(counter2 == 8){
            printf("solvable\n");
        } else {
            printf("unsolvable\n");
        }
    }
    //printf("correct\n");
    return 0;
}
