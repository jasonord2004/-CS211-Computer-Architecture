#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;  
};

// Insert node in sorted order 
void insert(struct Node** head, int data) {
  
    struct Node* new_node = malloc(sizeof(struct Node));
    new_node->data = data;
    
    if(*head == NULL || (*head)->data >= data) {
        new_node->next = *head;
        *head = new_node;
    } else {
        struct Node* current = *head;
        while(current->next != NULL && 
            current->next->data < data) {
            current = current->next;
        }
        
        new_node->next = current->next;
        current->next = new_node;
    }
}

// Delete node with given data
void delete(struct Node** head, int data) {
  
    struct Node *current = *head;
    struct Node *prev = NULL;
    
    if(current != NULL && current->data == data) {
        *head = current->next;
        free(current);
        return;
    }
    
    while(current != NULL && current->data != data) {
        prev = current;
        current = current->next;
    }
    
    if(current == NULL) return;
    
    prev->next = current->next;  
    free(current);
}

int main() {

    char op;
    int num;
    int x = 0;
    int i = 0;

    struct Node* head = NULL;
    
    while(scanf("%c %d", &op, &num) != EOF) {

        struct Node* current = head;
        while (current != NULL) {
            if (current->data == num) {
                i = 1; 
            }
            current = current->next;
        }

        if(op == 'i' && i == 0) {
            insert(&head, num);
        } else if(op == 'd'){
            delete(&head, num); 
        } else {
            i = 0;
        }

        int count = 0;
        struct Node* curr = head;
        
        while(curr != NULL) {
            count++;
            curr = curr->next;
        }

        if(x%2 == 0){
            printf("%d :", count); 
            curr = head;
            while(curr != NULL) {
                printf(" %d", curr->data);
                curr = curr->next;
            }
            printf("\n");
        }
        //printf("ITERATION: %d\n", x);
        x = x + 1;
    }
    struct Node* curr = head; 
    while (curr != NULL) {
        struct Node* temp = curr->next;
        free(curr);
        curr = temp;
    }
    return 0;
}