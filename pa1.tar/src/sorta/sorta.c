#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

void merge(char* arr[], int left, int mid, int right) 
{ 
    int i, j, k; 
    int n1 = mid - left + 1; 
    int n2 = right - mid; 

    char** l;
    l = malloc(n1 * sizeof(char*));

    char** r;
    r = malloc(n1 * sizeof(char*));
  
    // Copy data to temp arrays 
    // L[] and R[] 
    for (i = 0; i < n1; i++){
        l[i] = arr[left + i];
    }
         
    for (j = 0; j < n2; j++){
        r[j] = arr[mid + 1 + j]; 
    }
        
  
    // Merge the temp arrays back 
    // into arr[l..r] 
    // Initial index of first subarray 
    i = 0; 
  
    // Initial index of second subarray 
    j = 0; 
  
    // Initial index of merged subarray 
    k = left; 
    while (i < n1 && j < n2) { 
        if (strcmp(l[i],r[j]) < 0) {
                arr[k] = l[i]; 
                i++; 
            } else { 
                arr[k] = r[j]; 
                j++; 
            } 
        k++; 
    } 
  
    // Copy the remaining elements 
    // of L[], if there are any 
    while (i < n1) { 
        arr[k] = l[i]; 
        i++; 
        k++; 
    } 
  
    // Copy the remaining elements of 
    // R[], if there are any 
    while (j < n2) { 
        arr[k] = r[j]; 
        j++; 
        k++; 
    }   

    free(l);
    free(r);

} 

void mergeSort(char* arr[], int left, int right) 
{ 
    if (left < right) { 
        int mid = (left + right) / 2; 
  
        // Sort first and second halves 
        mergeSort(arr, left, mid); 
        mergeSort(arr, mid + 1, right); 


        merge(arr, left, mid, right); 
    } 
} 

int main(int argc, char* argv[]){
    if (argc == 1){
        return 0;
    }

    int left;
    int right;

    left = 1;
    right = argc - 1;

    mergeSort(argv, left, right); 
    
    int i;
    for(i = 1; i < argc; i++){

        printf("%s\n", argv[i]);
    }
    return 0;

}
