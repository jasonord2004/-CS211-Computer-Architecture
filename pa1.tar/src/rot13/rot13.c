#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main (int argc, char* argv[]){
	// if (argc != 1){
	// 	return 0;
	// }
	int i, j; 

	for(i = 1; i < argc; i++){
		for (j = 0; j < argv[i][j]; j++){
			if(isalpha(argv[i][j])){
				if(isupper(argv[i][j])){
					if(argv[i][j] >= 'N'){
						putchar((int) argv[i][j]-13);
					}else{
						putchar((int) argv[i][j]+13);
					}
				}else if(argv[i][j] >= 'n'){
					putchar((int) argv[i][j]-13);
				}else{
					putchar((int) argv[i][j]+13);
				}
			}
			else{
				putchar((int) argv[i][j]);
			}
		}
		printf("\n");
	}
	return 0;


}
